// Day 1 (1)
let arrayOne=[1,2,3]
let arrayTwo=["A","B","C"]
let arrayThree=[11,22,33]

// Day 1 (2)
let mergeOneTwo = [...arrayOne, ...arrayTwo]
console.log(mergeOneTwo)

// Day 1 (3)
let mergeTwoThree = [...arrayTwo, ...arrayThree]
console.log(mergeTwoThree)

// Day 1 (4)
mergeTwoThree = [...mergeTwoThree,4,5,6]
console.log(mergeTwoThree)

// Day12 1
let user={userName: "Kyaw",age: 24,city: "Yangon",todos: {t1:"cooking" ,t2:"sleeping"}}
let {userName,age,city,todos: {t1,t2}}=user
console.log(userName)
console.log(age)
console.log(city)
console.log(t1)
console.log(t2)

// Day12 2
let arr= ["apple", "orange",[1,2,3]]
let [fruit1,fruit2,nextArray]=arr
console.log(fruit1)
console.log(fruit2)
console.log(nextArray)